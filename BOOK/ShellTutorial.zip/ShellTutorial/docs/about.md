# 关于&致谢 <!-- {docsify-ignore-all} -->

关于本书存在的任何问题以及建议，均可以给我们发送邮件，也可以直接在本页下方留言。

电子邮件: archlinuxstudio@tutamail.com  
Telegram 电报群: [ArchLinuxStudio🇨🇦🏳️‍⚧️🏳️‍🌈](https://t.me/FSF_Ministry_of_Truth)
Matrix 群组: [Matrix Group:ArchLinuxStudio🇨🇦🏳️‍⚧️🏳️‍🌈](https://matrix.to/#/#ArchLinuxStudio:matrix.org)

## 致谢

向所有自由软件开发者、布道者与先行者致敬。
